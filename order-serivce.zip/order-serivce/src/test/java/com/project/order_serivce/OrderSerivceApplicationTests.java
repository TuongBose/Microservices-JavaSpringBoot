package com.project.order_serivce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderSerivceApplicationTests {

	@Test
	void contextLoads() {
	}

}
