package com.example.user_serivce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserSerivceApplicationTests {

	@Test
	void contextLoads() {
	}

}
